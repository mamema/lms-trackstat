ALTER TABLE track_statistics ADD COLUMN musicbrainz_id varchar(40) AFTER url;
