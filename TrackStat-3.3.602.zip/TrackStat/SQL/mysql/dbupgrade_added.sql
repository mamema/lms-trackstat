ALTER TABLE track_statistics ADD COLUMN added int(10) unsigned AFTER playCount;
