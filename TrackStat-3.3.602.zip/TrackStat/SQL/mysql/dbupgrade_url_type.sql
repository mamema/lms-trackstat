ALTER TABLE track_statistics modify url varchar(511) not null;
ALTER TABLE track_history modify url varchar(511) not null;
